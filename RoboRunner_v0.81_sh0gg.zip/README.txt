RoboRunner v0.81 - por sh0gg
---------------------------
Este juego requiere tener instalado Java 17 para funcionar correctamente.
Puedes descargarlo desde:
https://www.oracle.com/java/technologies/javase/jdk17-archive-downloads.html

Para jugar, simplemente ejecuta el archivo: RobotRunner.exe

¡Gracias por jugar
